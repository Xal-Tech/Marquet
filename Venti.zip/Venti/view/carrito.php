<!DOCTYPE html>
<html lang="es">
<head>
	<link rel="stylesheet" type="text/css" href="../css/base.css">
	<?php 
		include '../inc/link.php';
	?>
	<meta charset="UTF-8">
	<title>Mi carrito</title>
</head>
<body>
	<?php 
		include '../inc/navbar.php';
		include '../inc/jumbutron.php'
	 ?>

	<center><div>
	Tus pedidos
	</div></center>
</body>
</html>
