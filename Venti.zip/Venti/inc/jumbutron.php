<div class="jumbotron" >
	<div class="row no-gutters text-center align-items-center">
		<div class="col-8 col-md-8">
			<span style="font-family: Pacifico; color: white; font-size: 6vw; float: left;">MARQUET</span>
		</div>
		<div class="col-2 col-md-2">
		</div>
		<div class="col-2 col-md-2">
			<img class="img-fluid" src="../images/logo-marquet.png" alt="Logo" >
		</div>
	</div>
</div>