<div class="navbar container-fluid fixed-bottom text-center" style="color: white;height: 60px; background-color: gray; margin-bottom: 60px;">
	<div class="col">
		<a class="nav-link btn" href="#" style="color: white;">Carrito <span class="material-icons md-light btn">shopping_cart</span></a>
	</div>
</div>