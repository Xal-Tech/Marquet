<div class="navbar container-fluid fixed-bottom" style="height: 60px; background-color: #4CAF50;">
  <div class="col pad0">
    <center>
      <a class="nav-link" href="miEmpresa.php"><span class="material-icons md-light">person</span></a>
    </center>
  </div>
  <div class="col pad0">
    <center>
      <a class="nav-link" href="index.php"><span class="material-icons md-light">store</span></a>
    </center>
  </div>
  <div class="col pad0">
    <center>
      <a class="nav-link" href="venta.php"><span class="material-icons md-light">local_atm</span></a>
    </center>
  </div>
  <div class="col pad0">
    <center>
      <a class="nav-link" href="#"><span class="material-icons md-light">info</span></a>
    </center>
  </div>
</div>

<nav class="navbar navbar-expand-sm navbar-dark fixed-bottom d-none d-lg-block" style="height: 60px; background-color: #4CAF50;">
    <div class="navbar-nav container nav-pills nav-fill" style="padding: 0px;">
      <div class="nav-item col">
        <a class="nav-link" href="miEmpresa.php">Mi cuenta <span class="material-icons md-light btn">person</span></a>
      </div> 
      <div class="nav-item col">
        <a class="nav-link" href="catalogo.php">Catalogo <span class="material-icons md-light btn">store</span></a>
      </div> 
      <div class="nav-item col">
        <a class="nav-link" href="venta.php">Vender <span class="material-icons md-light btn">local_atm</span></a>
      </div> 
      <div class="nav-item col">
        <a class="nav-link" href="#">Info <span class="material-icons md-light btn">info</span></a>
      </div> 
    </div>
</nav>